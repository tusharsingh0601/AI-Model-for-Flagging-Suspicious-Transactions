from django.urls import path
from django.contrib.auth import views as auth_views # 1. Import built-in auth views
from . import views
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # --- Main Pages ---
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    path('admin/', admin.site.urls), # <-- CRITICAL: Must be here!
    path('', include('transactions.urls')),

    # --- Authentication (The Fix) ---
    
    # 1. LOGIN: Use Django's built-in view, but tell it where our HTML is
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    
    # 2. LOGOUT: Redirect to home after logging out
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),
    
    # 3. SIGNUP: This uses our custom view because we need to save the user
    path('signup/', views.signup, name='signup'),
    
    # --- API for AI ---
    path('predict/', views.predict, name='predict'),
]