import joblib
import os
import pandas as pd  # <--- Changed from numpy to pandas

def predict_fraud(amount):
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(current_dir, 'model_v1.pkl')

        if not os.path.exists(model_path):
            return False

        model = joblib.load(model_path)
        
        # FIX: Create a DataFrame with the column name 'amount'
        # This matches exactly how we trained it, silencing the warning.
        input_data = pd.DataFrame([[amount]], columns=['amount'])

        prediction = model.predict(input_data)[0]
        
        # DEBUG PRINT
        print(f"DEBUG: AI Prediction for {amount}: {prediction}")

        return bool(prediction == 1)

    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        return False