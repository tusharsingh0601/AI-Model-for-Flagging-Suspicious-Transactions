# transactions/ml_engine/train_model.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

# 1. Generate Fake Data (for demonstration)
# We will train on just one feature: 'amount' to match your current form.
# In a real scenario, you would have features like 'location', 'time', 'merchant_type'.
print("Generating synthetic data...")
data = pd.DataFrame({
    'amount': np.random.randint(1, 20000, 1000) # 1000 random transactions
})

# logic: If amount > 8000 OR amount is exactly 5000 (just to add a pattern), mark as fraud
data['is_fraud'] = np.where((data['amount'] > 8000) | (data['amount'] == 5000), 1, 0)

X = data[['amount']]
y = data['is_fraud']

# 2. Train the Model
print("Training Random Forest Model...")
model = RandomForestClassifier(n_estimators=50, random_state=42)
model.fit(X, y)

# 3. Save the Model
# This saves the file in the SAME folder as this script
current_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(current_dir, 'model_v1.pkl')

joblib.dump(model, model_path)
print(f"Success! Model saved to: {model_path}")